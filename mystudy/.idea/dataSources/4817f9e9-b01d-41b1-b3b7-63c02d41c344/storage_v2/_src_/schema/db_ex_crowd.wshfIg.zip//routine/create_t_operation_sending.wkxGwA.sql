create
    definer = root@`172.16.%` procedure create_t_operation_sending(IN dayInt varchar(32))
BEGIN
set @create_t_operation_sending = CONCAT('create table t_operation_sending_',dayInt,
 "
 (
  id int(11) NOT NULL AUTO_INCREMENT COMMENT '计划ID',
  operation_id int(11) NOT NULL COMMENT '运营计划ID',
  operation_type tinyint(4) NOT NULL DEFAULT 2 COMMENT '运营计划类型 1-长期计划 2-定时计划',
  app_id varchar(64) NOT NULL DEFAULT '' COMMENT '店铺ID',
  user_id varchar(64) NOT NULL DEFAULT '' COMMENT '用户ID',
  start_hour timestamp NOT NULL DEFAULT '1970-11-11 11:11:11' COMMENT '发送开始时间',
  is_coupon tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否发送优惠券 0-不发送 1-发送',
  coupon_res tinyint(4) NOT NULL DEFAULT '0' COMMENT '优惠券发送结果 0-未发送 1-已发送 2-发送失败',
  coupon_time timestamp NOT NULL DEFAULT '1970-11-11 11:11:11' COMMENT '优惠券发送时间',
  is_sms tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否发送短信 0-不发送 1-发送',
  sms_res tinyint(4) NOT NULL DEFAULT '0' COMMENT '短信发送结果 0-未发送 1-已发送 2-发送中 3-发送失败',
  sms_time timestamp NOT NULL DEFAULT '1970-11-11 11:11:11' COMMENT '短信发送时间',
  sms_task_id varchar(64) NOT NULL DEFAULT '' COMMENT '短信发送批次ID',
  sms_phone varchar(16) NOT NULL DEFAULT '' COMMENT '用户手机号',
  is_message tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否发送店铺消息 0-不发送 1-发送',
  message_res tinyint(4) NOT NULL DEFAULT '0' COMMENT '店铺消息发送结果 0-未发送 1-已发送',
  message_time timestamp NOT NULL DEFAULT '1970-11-11 11:11:11' COMMENT '店铺消息发送时间',
  get_lable varchar(64) NOT NULL DEFAULT '0' COMMENT '处理标识 为0则表示未处理',
  state tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态 0-无效 1-有效',
  end_date date NOT NULL DEFAULT '9999-01-01' COMMENT '运营计划的截止日期',
  created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  updated_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (id),
  KEY index_app_id (app_id),
  KEY index_created_at (created_at),
  KEY index_operation_lable (operation_id,get_lable),
  KEY index_start_hour (start_hour,get_lable),
  KEY index_task_id (sms_phone,sms_task_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='运营计划当日需发送权益礼包和通知列表（长期计划）'");       
 PREPARE create_t_operation_sending FROM @create_t_operation_sending;
 EXECUTE create_t_operation_sending;
  END;

