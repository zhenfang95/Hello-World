create
    definer = lanceliao@`%` procedure create_table_t_order_trade_from_wx()
BEGIN

 set @suffix=date_format(now(), '%Y_%m');

 set @sqlStr=CONCAT('CREATE TABLE t_order_trade_from_wx_',@suffix, "(

  id             int auto_increment comment '支付回调日志'

                                primary key,

                            appid          varchar(64)                null comment '微信公众号id',

                            shop_id          varchar(64)                null comment '店铺id',

                            transaction_id varchar(64)                null comment '微信支付订单号',

                            wx_duration    int(11) unsigned default 0 not null comment '支付时间与收到微信回调的时间间隔，单位秒',

                            time_end       varchar(64)                null comment '支付完成时间',

                            total_fee      varchar(64)                null comment '订单金额',

                            trade_state     varchar(64)                null comment '交易状态',

                            trade_type     varchar(64)                null comment '交易类型',

                            out_trade_no   varchar(64)                null comment '外部订单号',

                            result_code    varchar(64)                null comment '业务结果',

                            return_code    varchar(64)                null comment '返回状态码，通信标识',

                            attach         varchar(64)                null comment '商家数据包',

                            front_callback varchar(64)                null comment '前端微信回调',

                            bank_type      varchar(64)                null comment '付款银行',

                            cash_fee       varchar(64)                null comment '金额',

                            fee_type       varchar(64)                null comment '货币类型',

                            is_subscribe   varchar(64)                null comment '是否已关注',

                            mch_id         varchar(64)                null comment '商户id',

                            nonce_str      varchar(64)                null comment '随机字符串',

                            openid         varchar(64)                null comment '用户open_id',

                            sign           varchar(64)                null comment '签名',

                            created_at     timestamp                  null comment '创建时间',

                         KEY `key_shopid_created_appid` (`shop_id`,`appid`, `created_at`),

                         KEY `key_created_at` (`created_at`)

                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='主动查询微信表’;");

 PREPARE stmt from @sqlStr;

 EXECUTE stmt;

END;

