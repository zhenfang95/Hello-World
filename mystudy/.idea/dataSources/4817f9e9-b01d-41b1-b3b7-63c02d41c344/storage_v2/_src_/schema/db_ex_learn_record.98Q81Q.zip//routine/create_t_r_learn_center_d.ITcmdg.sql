create
    definer = root@`172.16.%` procedure create_t_r_learn_center_d(IN dayInt bigint)
BEGIN
set @create_t_r_learn_center_d = CONCAT('create table t_r_learn_center_d_',dayInt,
"
(app_id varchar(64) NOT NULL COMMENT '应用Id',
user_id varchar(64) NOT NULL COMMENT '内部用户唯一标识，需程序随机生成',
learn_time int DEFAULT '0' COMMENT '用户当日学习时长 单位秒',
all_learn_time bigint DEFAULT '0' COMMENT '用户累计学习时长 单位秒',
created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
updated_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
Primary Key (app_id,user_id)
) COMMENT='用户学习记录结果表（表名日期为当天日期）'
"
);

PREPARE create_t_r_learn_center_d FROM @create_t_r_learn_center_d;
EXECUTE create_t_r_learn_center_d;
END;

