create
    definer = lanceliao@`%` procedure drop_table_learn_center_d(IN dayInt bigint)
BEGIN
set @drop_table_learn_center_d = CONCAT('drop table t_r_learn_center_d_',dayInt,"");       
        PREPARE drop_table_learn_center_d FROM @drop_table_learn_center_d;
        EXECUTE drop_table_learn_center_d;
  END;

