create definer = lanceliao@`%` event create_table_t_order_trade_from_wx on schedule
    every '1' MONTH
        starts '2019-12-01 00:00:00'
    enable
    do
    BEGIN

 call create_table_t_order_trade_from_wx();

END;

