create view v_right_data as select `db_report_portal`.`privilege`.`master_value`   AS `f_user_name`,
                                   `db_report_portal`.`privilege`.`access`         AS `f_content_type`,
                                   `db_report_portal`.`privilege`.`access_value`   AS `f_content_value`,
                                   `db_report_portal`.`privilege`.`operation_type` AS `f_operate_type`
                            from `db_report_portal`.`privilege`
                            where (`db_report_portal`.`privilege`.`master` = 'user')
                            union all
                            select `ur`.`user_name`     AS `f_user_name`,
                                   `p`.`access`         AS `f_content_type`,
                                   `p`.`access_value`   AS `f_content_value`,
                                   `p`.`operation_type` AS `f_operate_type`
                            from (`db_report_portal`.`privilege` `p`
                                     join `db_report_portal`.`user_role` `ur`
                                          on (((`p`.`master_value` = `ur`.`role_id`) and (`p`.`master` = 'role'))))
                            union all
                            select `db_report_portal`.`t_user_content`.`f_user_key`     AS `f_user_name`,
                                   (case `db_report_portal`.`t_user_content`.`f_type`
                                        when 0 then 'content_role'
                                        when 1 then 'table'
                                        when 2 then 'sql'
                                        when 3 then 'theme'
                                        when 4 then 'sql_template'
                                        when 5 then 'view'
                                        when 6 then 'case'
                                        when 7 then 'database_conf' end)                AS `f_content_type`,
                                   `db_report_portal`.`t_user_content`.`f_content_key`  AS `f_content_value`,
                                   `db_report_portal`.`t_user_content`.`f_operate_type` AS `f_operate_type`
                            from `db_report_portal`.`t_user_content`
                            union all
                            select `uc`.`f_user_key`                     AS `f_user_name`,
                                   (case `rc`.`f_type`
                                        when 0 then 'content_role'
                                        when 1 then 'table'
                                        when 2 then 'sql'
                                        when 3 then 'theme'
                                        when 4 then 'sql_template'
                                        when 5 then 'view'
                                        when 6 then 'case'
                                        when 7 then 'database_conf' end) AS `f_content_type`,
                                   `rc`.`f_content_key`                  AS `f_content_value`,
                                   `uc`.`f_operate_type`                 AS `f_operate_type`
                            from (`db_report_portal`.`t_role_content` `rc`
                                     join `db_report_portal`.`t_user_content` `uc`
                                          on (((`rc`.`f_role_key` = `uc`.`f_content_key`) and (`uc`.`f_type` = 0))));

