create view v_field_def as
select `db_report_portal`.`t_field_def`.`f_id`                 AS `f_id`,
       `db_report_portal`.`t_field_def`.`f_table_id`           AS `f_table_id`,
       `db_report_portal`.`t_field_def`.`f_table_key`          AS `f_table_key`,
       `db_report_portal`.`t_field_def`.`f_table_name`         AS `f_table_name`,
       `db_report_portal`.`t_field_def`.`f_order_num`          AS `f_order_num`,
       `db_report_portal`.`t_field_def`.`f_field_key`          AS `f_field_key`,
       `db_report_portal`.`t_field_def`.`f_field_name`         AS `f_field_name`,
       `db_report_portal`.`t_field_def`.`f_field_type`         AS `f_field_type`,
       `db_report_portal`.`t_field_def`.`f_field_desc`         AS `f_field_desc`,
       `db_report_portal`.`t_field_def`.`f_unit`               AS `f_unit`,
       `db_report_portal`.`t_field_def`.`f_primary_key`        AS `f_primary_key`,
       `db_report_portal`.`t_field_def`.`f_create_user`        AS `f_create_user`,
       `db_report_portal`.`t_field_def`.`f_modify_user`        AS `f_modify_user`,
       `db_report_portal`.`t_field_def`.`f_create_time`        AS `f_create_time`,
       `db_report_portal`.`t_field_def`.`f_modify_time`        AS `f_modify_time`,
       `db_report_portal`.`t_field_def`.`f_valid`              AS `f_valid`,
       `db_report_portal`.`t_field_def`.`f_default_value`      AS `f_default_value`,
       `db_report_portal`.`t_field_def`.`f_aggregation_method` AS `f_aggregation_method`,
       `db_report_portal`.`t_field_def`.`f_security_class`     AS `f_security_class`,
       `db_report_portal`.`t_field_def`.`f_category`           AS `f_category`,
       `db_report_portal`.`t_field_def`.`f_time_format`        AS `f_time_format`,
       `db_report_portal`.`t_field_def`.`f_entity_code`        AS `f_entity_code`,
       `db_report_portal`.`t_field_def`.`f_process_logic`      AS `f_process_logic`,
       `db_report_portal`.`t_field_def`.`f_example`            AS `f_example`
from `db_report_portal`.`t_field_def`;

-- comment on column v_field_def.f_table_id not supported: 表id

-- comment on column v_field_def.f_table_key not supported: 表名

-- comment on column v_field_def.f_table_name not supported: 表中文名

-- comment on column v_field_def.f_order_num not supported: 排序

-- comment on column v_field_def.f_field_key not supported: 字段名

-- comment on column v_field_def.f_field_name not supported: 字段中文名

-- comment on column v_field_def.f_field_type not supported: 字段类型

-- comment on column v_field_def.f_field_desc not supported: 字段描述

-- comment on column v_field_def.f_unit not supported: 单位

-- comment on column v_field_def.f_primary_key not supported: 是否主键

-- comment on column v_field_def.f_create_user not supported: 创建人

-- comment on column v_field_def.f_modify_user not supported: 最后修改人

-- comment on column v_field_def.f_create_time not supported: 创建时间

-- comment on column v_field_def.f_modify_time not supported: 最后修改时间

-- comment on column v_field_def.f_valid not supported: 有效状态

-- comment on column v_field_def.f_default_value not supported: 默认值

-- comment on column v_field_def.f_aggregation_method not supported: 聚合方法,支持ADD MIN MAX REPLACE

-- comment on column v_field_def.f_security_class not supported: 密级，1 公开 2 保密 3 机密 4 绝密

-- comment on column v_field_def.f_category not supported: 字段类别，1 "指标" 2 "维度" 3 "属性" 4 "时间"

-- comment on column v_field_def.f_time_format not supported: 1 "日期" 2 "时间"

-- comment on column v_field_def.f_entity_code not supported: 对应实体编码

-- comment on column v_field_def.f_process_logic not supported: 字段加工逻辑

-- comment on column v_field_def.f_example not supported: 数据样本

