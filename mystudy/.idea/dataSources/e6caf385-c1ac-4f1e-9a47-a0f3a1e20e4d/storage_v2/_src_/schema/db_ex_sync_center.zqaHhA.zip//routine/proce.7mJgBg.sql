create
    definer = code_viewer@`%` procedure proce()
begin
  
            CREATE TABLE IF NOT EXISTS `t_send_goods_queue_result_2019_10` (
                      `id` INT(11) NOT NULL AUTO_INCREMENT,
                     `app_id` varchar(64) NOT NULL COMMENT '应用id',
                     `order_id` varchar(64) NOT NULL COMMENT '订单id',
                     `state` TINYINT(4) DEFAULT '0' COMMENT '发货结果：0-未开始，1-发货成功，2-发货失败',
                     `remark` varchar(128) DEFAULT NULL COMMENT '备注',
                     `is_deleted` TINYINT(4) DEFAULT '0' COMMENT '是否删除(1-是 0-否)',
                     `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
                     `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间，有修改自动更新',
                     PRIMARY KEY (`id`),
                     INDEX `index_app_source_target_user` (`app_id`, `order_id`)
                    ) COMMENT='发货队列同步结果' DEFAULT CHARSET='utf8mb4' ENGINE=InnoDB;
end;

