create definer = root@`%` event create_table_t_send_goods_queue_result on schedule
    every '1' MONTH
        starts '2019-11-01 00:00:00'
    enable
    do
    BEGIN
 call create_table_t_send_goods_queue_result();
END;

