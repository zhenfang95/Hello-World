create
    definer = out_root@`%` procedure sum1(IN a int)
begin
    declare sum int default 0;  -- default 是指定该变量的默认值
    declare i int default 0;
while i<=a DO -- 循环开始
    set @v = concat("DELETE FROM t_resource_",i,' where app_id = \'appXDVnQXT96916\'');
    PREPARE stmt1 FROM @v ;
    EXECUTE stmt1 ;
    set sum=sum+i;
    set i=i+1;
end while; -- 循环结束
select sum;  -- 输出结果
end;

