create
    definer = out_root@`%` procedure create_table_t_distribution_change_log()
BEGIN
	set @suffix=date_format(now(), '%Y_%m');
	set @sqlStr=CONCAT('CREATE TABLE if not exist t_distribution_change_log_',@suffix,"(
              `id` int(11) NOT NULL AUTO_INCREMENT,
              `app_id` varchar(64) NOT NULL,
              `operation_type` int(11) NOT NULL COMMENT '1001 推广员等级，1002 推广员上下级，1003 资源分销比例  1004绑定客户',
              `operation_user_id` varchar(64) NOT NULL DEFAULT '' COMMENT '操作人id',
              `operation_id` varchar(64) NOT NULL DEFAULT '' COMMENT '修改对象的id',
              `operation_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
              `previous_value` text NOT NULL COMMENT '前值',
              `revision_value` text NOT NULL COMMENT '修改值',
              `is_deleted` tinyint(4) NOT NULL DEFAULT '0' COMMENT '0正常 1删除',
							`created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '记录时间',
              `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
              PRIMARY KEY (`id`),
              KEY `operation_id` (`app_id`,`operation_type`,`operation_id`) USING BTREE,
              KEY `operation_user_id` (`app_id`,`operation_user_id`) USING BTREE,
              KEY `operation_time` (`operation_time`) USING BTREE
            ) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COMMENT='推广员关键信息修改记录表';");
	PREPARE stmt from @sqlStr;
	EXECUTE stmt;

END;

