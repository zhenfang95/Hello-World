create definer = root@`%` event event_operation_sending on schedule
    every '1' DAY
        starts '2019-11-12 15:58:38'
    enable
    do
    BEGIN  call create_t_operation_sending (DATE_FORMAT(date_add(curdate(),interval 2 day),'%Y_%m_%d')); END;

