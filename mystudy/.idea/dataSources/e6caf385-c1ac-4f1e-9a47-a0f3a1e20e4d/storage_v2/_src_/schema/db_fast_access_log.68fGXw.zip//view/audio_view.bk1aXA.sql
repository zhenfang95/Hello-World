create view audio_view as
select `db_fast_access_log`.`t_visit`.`user_id`    AS `user_id`,
       `db_fast_access_log`.`t_visit`.`target_url` AS `target_url`,
       `db_fast_access_log`.`t_visit`.`referer`    AS `referer`,
       `db_fast_access_log`.`t_visit`.`type`       AS `type`,
       `db_fast_access_log`.`t_visit`.`param_1`    AS `param_1`,
       `db_fast_access_log`.`t_visit`.`param_2`    AS `param_2`,
       `db_fast_access_log`.`t_visit`.`ip`         AS `ip`,
       `db_fast_access_log`.`t_visit`.`agent`      AS `agent`,
       `db_fast_access_log`.`t_visit`.`created_at` AS `created_at`
from `db_fast_access_log`.`t_visit`
where (`db_fast_access_log`.`t_visit`.`target_url` like '%/audio_analyse');

-- comment on column audio_view.user_id not supported: 用户id

-- comment on column audio_view.target_url not supported: 访问的接口

-- comment on column audio_view.type not supported: 同一接口的不同类型

-- comment on column audio_view.param_1 not supported: 复用参数一

-- comment on column audio_view.param_2 not supported: 复用参数二

-- comment on column audio_view.ip not supported: 用户的ip

-- comment on column audio_view.agent not supported: 客户端信息

-- comment on column audio_view.created_at not supported: 创建时间

