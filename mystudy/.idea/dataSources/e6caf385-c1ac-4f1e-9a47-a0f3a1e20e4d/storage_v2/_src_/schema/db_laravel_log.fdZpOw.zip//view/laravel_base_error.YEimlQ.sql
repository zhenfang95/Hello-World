create view laravel_base_error as
select `db_laravel_log`.`t_base_develop_error_log`.`id`           AS `id`,
       `db_laravel_log`.`t_base_develop_error_log`.`project_type` AS `project_type`,
       `db_laravel_log`.`t_base_develop_error_log`.`request_url`  AS `request_url`,
       `db_laravel_log`.`t_base_develop_error_log`.`uri_path`     AS `uri_path`,
       `db_laravel_log`.`t_base_develop_error_log`.`describe`     AS `describe`,
       `db_laravel_log`.`t_base_develop_error_log`.`content`      AS `content`,
       `db_laravel_log`.`t_base_develop_error_log`.`referer`      AS `referer`,
       `db_laravel_log`.`t_base_develop_error_log`.`memory`       AS `memory`,
       `db_laravel_log`.`t_base_develop_error_log`.`ip`           AS `ip`,
       `db_laravel_log`.`t_base_develop_error_log`.`server_ip`    AS `server_ip`,
       `db_laravel_log`.`t_base_develop_error_log`.`base_path`    AS `base_path`,
       `db_laravel_log`.`t_base_develop_error_log`.`method`       AS `method`,
       `db_laravel_log`.`t_base_develop_error_log`.`app_id`       AS `app_id`,
       `db_laravel_log`.`t_base_develop_error_log`.`params`       AS `params`,
       `db_laravel_log`.`t_base_develop_error_log`.`created_at`   AS `created_at`
from `db_laravel_log`.`t_base_develop_error_log`
where (`db_laravel_log`.`t_base_develop_error_log`.`created_at` > curdate());

-- comment on column laravel_base_error.id not supported: 自增id

-- comment on column laravel_base_error.project_type not supported: 项目 1-C端登录、2-B端登录、3-O端登录、4-模板消息发送、5-微信消息接收、6-SafeMonitor工程、7-商户助手小程序后台、8-FirstGateway、9-KeepOnline

-- comment on column laravel_base_error.request_url not supported: 请求的URL

-- comment on column laravel_base_error.uri_path not supported: 请求路径

-- comment on column laravel_base_error.`describe` not supported: 描述

-- comment on column laravel_base_error.content not supported: 日志内容

-- comment on column laravel_base_error.memory not supported: php请求消耗内存

-- comment on column laravel_base_error.ip not supported: 用户ip

-- comment on column laravel_base_error.server_ip not supported: 当前服务器ip

-- comment on column laravel_base_error.base_path not supported: 当前项目服务器根目录

-- comment on column laravel_base_error.method not supported: 请求类型

-- comment on column laravel_base_error.app_id not supported: 应用id

-- comment on column laravel_base_error.params not supported: 参数

-- comment on column laravel_base_error.created_at not supported: 创建时间

