create
    definer = root@`%` procedure create_t_r_learn_center_w(IN dayInt bigint)
BEGIN
set @create_t_r_learn_center_w = CONCAT('create table t_r_learn_center_w_',dayInt,
"
(
batch_no varchar(64) NOT NULL COMMENT '批次号 YYYYmmddHH',

app_id varchar(64) NOT NULL COMMENT '店铺id',

user_id varchar(64) NOT NULL COMMENT '用户id',

ranking int DEFAULT '0' COMMENT '排名（按本周学习时长）',

learn_num int DEFAULT '0' COMMENT '本周完成课程',

learn_time bigint DEFAULT '0' COMMENT '本周学习时长 单位秒',

last_learn_time varchar(32) COMMENT '本周最晚学习时间',

is_read tinyint DEFAULT '0' COMMENT '是否已读，0-否，1-是',

created_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',

updated_at timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',

Primary Key (app_id,batch_no,user_id)
) COMMENT '用户学习周报表（表名日期为当周周一日期）'

"
);       
        PREPARE create_t_r_learn_center_w FROM @create_t_r_learn_center_w;
        EXECUTE create_t_r_learn_center_w;
  END;

