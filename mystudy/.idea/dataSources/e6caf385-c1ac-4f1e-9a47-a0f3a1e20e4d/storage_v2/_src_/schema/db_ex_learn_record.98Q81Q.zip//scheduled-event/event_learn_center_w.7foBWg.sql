create definer = root@`%` event event_learn_center_w on schedule
    every '1' WEEK
        starts '2019-10-29 19:55:17'
    enable
    do
    BEGIN
        call create_t_r_learn_center_w (DATE_FORMAT(subdate(curdate(),date_format(curdate(),'%w')-8),'%Y%m%d'));
END;

