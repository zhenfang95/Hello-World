create definer = root@`%` event event_learn_center_d on schedule
    every '1' DAY
        starts '2019-10-29 19:55:01'
    enable
    do
    BEGIN
 call create_t_r_learn_center_d (DATE_FORMAT(date_add(curdate(),interval 2 day),'%Y%m%d'));
END;

