create
    definer = out_root@`%` procedure insert_10WData()
begin
     declare i int default 0;
     while i < 100 do
         SELECT count(*) as cc FROM db_ex_component.t_vital_log WHERE created_at > now()-60*i and created_at < now()-60*(i-1);
         set i = i + 1;
    end while;
 end;

