create
    definer = root@`%` procedure create_table_t_orders_refund_flow()
BEGIN
 set @suffix=date_format(now(), '%Y');
 set @sqlStr=CONCAT('CREATE TABLE t_orders_refund_flow_',@suffix, "(
 `refund_id` varchar(64) NOT NULL COMMENT ''退款id：r_201902xxxx'',
 `app_id` varchar(64) NOT NULL COMMENT ''应用ID'',
 `order_id` varchar(64) NOT NULL COMMENT ''订单ID'',
 `out_order_id` varchar(64) NOT NULL COMMENT ''外部订单ID'',
 `transaction_id` varchar(64) NOT NULL COMMENT ''交易单号ID'',
 `out_refund_id` varchar(64) NOT NULL COMMENT ''外部退款单号'',
 `provider_refund_id` varchar(64) NOT NULL COMMENT ''第三方退款单号'',
 `resource_ids` varchar(1024) NOT NULL COMMENT ''商品id-json'',
 `order_price` int(11) NOT NULL DEFAULT ''0'' COMMENT ''订单金额'',
 `refund_price` int(11) NOT NULL DEFAULT ''0'' COMMENT ''退款金额'',
 `refund_type` tinyint(3) NOT NULL DEFAULT ''1'' COMMENT ''退款类型：1-全额退款、2-部分退款'',
 `flow_type` mediumint(9) NOT NULL DEFAULT ''0'' COMMENT ''流水类型：100-退款初始化(待退款) 101-退款中 102-退款成功 103-退款失败'',
 `state` tinyint(3) unsigned NOT NULL DEFAULT ''0'' COMMENT ''退款状态：0-待退款、1-退款中、2-退款成功、3-退款失败'',
 `process_state` varchar(255) NOT NULL DEFAULT ''0'' COMMENT ''执行流程结果步骤：{xxx:0} 0-初始态 1-执行成功 2-执行失败 3-超时 4-不需要执行'',
 `refund_time` timestamp NOT NULL DEFAULT ''0000-00-00 00:00:00'' COMMENT ''退款时间'',
 `remark` varchar(1024) NOT NULL DEFAULT '''' COMMENT ''B端退款备注'',
 `out_remark` varchar(1024) NOT NULL DEFAULT '''' COMMENT ''外部退款备注'',
 `refund_client_ip` varchar(32) NOT NULL DEFAULT '''' COMMENT ''操作者端ip'',
 `refund_operator` varchar(64) NOT NULL DEFAULT '''' COMMENT ''操作者'',
 `is_delete` tinyint(3) unsigned NOT NULL DEFAULT ''0'' COMMENT ''软删除：0-正常 1-已删除'',
 `refund_created_at` timestamp NOT NULL DEFAULT ''0000-00-00 00:00:00'' COMMENT ''退款创建时间'',
 `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT ''创建时间'',
 PRIMARY KEY (`refund_id`,`app_id`),
 KEY `index_app_id` (`app_id`,`order_id`),
 KEY `index_created_at_app_id` (`created_at`,`app_id`)
 ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT=''售后订单流水表'';");
 PREPARE stmt from @sqlStr;
 EXECUTE stmt;

END;

