create view t_orders_tmp as
select `orders`.`app_id`                      AS `app_id`,
       `orders`.`order_id`                    AS `order_id`,
       `orders`.`content_app_id`              AS `content_app_id`,
       `orders`.`cou_price`                   AS `cou_price`,
       `orders`.`count`                       AS `count`,
       unix_timestamp(`orders`.`created_at`)  AS `created_at`,
       `order_state`.`state`                  AS `order_state`,
       `order_type`.`type`                    AS `order_type`,
       `orders`.`out_order_id`                AS `out_order_id`,
       unix_timestamp(`orders`.`pay_time`)    AS `pay_time`,
       unix_timestamp(`orders`.`settle_time`) AS `settle_time`,
       `orders`.`is_renew`                    AS `is_renew`,
       `orders`.`price`                       AS `price`,
       `orders`.`distribute_type`             AS `distribute_type`,
       `orders`.`discount_price`              AS `distribute_price`,
       `orders`.`superior_distribute_price`   AS `superior_distribute_price`,
       `orders`.`payment_type`                AS `payment_type`,
       `orders`.`cu_id`                       AS `cu_id`,
       `orders`.`user_id`                     AS `user_id`,
       `orders`.`discount_id`                 AS `discount_id`,
       `orders`.`pay_way`                     AS `pay_way`,
       `orders`.`purchase_name`               AS `purchase_name`,
       `orders`.`resource_type`               AS `resource_type`,
       `orders`.`transaction_id`              AS `transaction_id`,
       `orders`.`use_collection`              AS `use_collection`,
       `orders`.`wx_app_type`                 AS `wx_app_type`
from `db_ex_business`.`t_orders` `orders`
         join `db_ex_business`.`order_state`
         join `db_ex_business`.`order_type`
where ((`orders`.`app_id` = `order_state`.`app_id`) and (`orders`.`order_id` = `order_state`.`order_id`) and
       (`orders`.`app_id` = `order_type`.`app_id`) and (`orders`.`order_id` = `order_type`.`order_id`));

-- comment on column t_orders_tmp.app_id not supported: 应用Id

-- comment on column t_orders_tmp.order_id not supported: 订单Id

-- comment on column t_orders_tmp.content_app_id not supported: 内容方应用Id

-- comment on column t_orders_tmp.cou_price not supported: 优惠价格:分

-- comment on column t_orders_tmp.count not supported: 购买数量，默认为1，团购时按实际情况填写

-- comment on column t_orders_tmp.out_order_id not supported: 成功支付的外部订单号(out_orders)

-- comment on column t_orders_tmp.is_renew not supported: 是否是续费订单：默认0-普通订单、1-会员续费、2-过期后购买、3-删除后购买

-- comment on column t_orders_tmp.price not supported: 价格（分）

-- comment on column t_orders_tmp.distribute_type not supported: 0.普通订单 1.分销订单

-- comment on column t_orders_tmp.distribute_price not supported: 折扣减免的价格:分

-- comment on column t_orders_tmp.superior_distribute_price not supported: 上级分销提成（分）提问者的分成提成（分）

-- comment on column t_orders_tmp.payment_type not supported: 付费类型：2-单笔、3-付费产品包、4-团购、5-单笔的购买赠送、6-产品包的购买赠送、7-问答提问、8-问答偷听、9-购买会员、10-会员的购买赠送、11-付费活动报名、12-打赏类型  13-单笔拼团 14-付费产品包拼团

-- comment on column t_orders_tmp.cu_id not supported: 用户优惠券id

-- comment on column t_orders_tmp.user_id not supported: 用户id

-- comment on column t_orders_tmp.discount_id not supported: 折扣id  若payment_type为13、14时存拼团(大团)id

-- comment on column t_orders_tmp.pay_way not supported: 支付渠道 默认0 -1-未指定支付方式 0-线上微信 1-线上支付宝 2-IOS支付 3-安卓支付 4-线下支付

-- comment on column t_orders_tmp.purchase_name not supported: 购买的资源名

-- comment on column t_orders_tmp.resource_type not supported: 资源类型：0-无（不通过资源的购买入口，如团购）、1-图文、2-音频、3-视频、4-直播、5-活动报名(若payment_type=14时，5-会员)、6-专栏、7-社群、8-大专栏、20-电子书

-- comment on column t_orders_tmp.transaction_id not supported: 微信支付交易单号

-- comment on column t_orders_tmp.use_collection not supported: 是否是来自代收 0-否 1-是

-- comment on column t_orders_tmp.wx_app_type not supported: 数据来源 0-小程序 1-公众号 10-开放平台 11-PC通用版 12-App 13-线下订单 20-抖音小程序 21-app内嵌H5

