create view order_type_tmp as
select (case
            when ((`db_ex_business`.`t_orders`.`payment_type` in (2, 3, 7, 8, 12, 15)) and
                  (`db_ex_business`.`t_orders`.`discount_id` = '') and (`db_ex_business`.`t_orders`.`cu_id` = '') and
                  (`db_ex_business`.`t_orders`.`is_renew` = 0) and
                  (`db_ex_business`.`t_orders`.`distribute_type` = 0) and (`db_ex_business`.`t_orders`.`source` = 0))
                then '2,'
            else '' end)                                                                            AS `is_normal`,
       (case when (`db_ex_business`.`t_orders`.`payment_type` in (5, 6)) then '4,' else '' end)     AS `is_gift`,
       (case when (`db_ex_business`.`t_orders`.`payment_type` in (13, 14)) then '6,' else '' end)   AS `is_group`,
       (case when (`db_ex_business`.`t_orders`.`cu_id` <> '') then '8,' else '' end)                AS `is_coupon`,
       (case when (`db_ex_business`.`t_orders`.`discount_id` like 'ma_gc%') then '10,' else '' end) AS `is_invite`,
       (case when (`db_ex_business`.`t_orders`.`discount_id` like 'ma_rd%') then '12,' else '' end) AS `is_convert`,
       (case when (`db_ex_business`.`t_orders`.`is_renew` in (1, 2, 3)) then '14,' else '' end)     AS `is_vip_renew`,
       (case
            when ((`db_ex_business`.`t_orders`.`payment_type` in (2, 3, 5, 6)) and
                  (`db_ex_business`.`t_orders`.`discount_id` like 'ma_5b%')) then '16,'
            else '' end)                                                                            AS `is_limit_discounts`,
       (case
            when (`db_ex_business`.`t_orders`.`discount_id` like 'ma_fs%') then '18,'
            else '' end)                                                                            AS `is_friend_boost`,
       (case when (`db_ex_business`.`t_orders`.`discount_id` like 'ma_if%') then '20,' else '' end) AS `is_fans_up`,
       (case when (`db_ex_business`.`t_orders`.`share_type` in (4, 5)) then '22,' else '' end)      AS `is_distribute`,
       (case
            when ((`db_ex_business`.`t_orders`.`share_type` = 8) and
                  (`db_ex_business`.`t_orders`.`distribute_type` = 1)) then '24,'
            else '' end)                                                                            AS `is_poster`,
       (case when (`db_ex_business`.`t_orders`.`discount_id` like 'ma_sk%') then '26,' else '' end) AS `is_spike`,
       (case when (`db_ex_business`.`t_orders`.`share_type` = 6) then '28,' else '' end)            AS `is_new_list`,
       (case when (`db_ex_business`.`t_orders`.`wx_app_type` = 10) then '30,' else '' end)          AS `is_api`,
       (case when (`db_ex_business`.`t_orders`.`source` = 1) then '66,' else '' end)                AS `is_others`,
       `db_ex_business`.`t_orders`.`app_id`                                                         AS `app_id`,
       `db_ex_business`.`t_orders`.`order_id`                                                       AS `order_id`
from `db_ex_business`.`t_orders`;

-- comment on column order_type_tmp.app_id not supported: 应用Id

-- comment on column order_type_tmp.order_id not supported: 订单Id

