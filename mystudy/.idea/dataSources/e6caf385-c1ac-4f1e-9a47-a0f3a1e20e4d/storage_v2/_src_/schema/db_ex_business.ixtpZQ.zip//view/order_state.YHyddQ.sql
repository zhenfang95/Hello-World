create view order_state as
select (case
            when (((`db_ex_business`.`t_orders`.`payment_type` in (7, 13, 14)) and
                   (`db_ex_business`.`t_orders`.`order_state` = 1) and
                   (`db_ex_business`.`t_orders`.`que_check_state` = 1) and
                   (`db_ex_business`.`t_orders`.`goods_type` = 0)) or
                  ((`db_ex_business`.`t_orders`.`payment_type` not in (7, 13, 14)) and
                   (`db_ex_business`.`t_orders`.`order_state` = 1) and
                   (`db_ex_business`.`t_orders`.`goods_type` = 0)) or
                  ((`db_ex_business`.`t_orders`.`order_state` = 1) and
                   (`db_ex_business`.`t_orders`.`ship_state` = 3) and (`db_ex_business`.`t_orders`.`goods_type` = 1)))
                then 1
            when (((`db_ex_business`.`t_orders`.`order_state` = 3) and
                   (`db_ex_business`.`t_orders`.`goods_type` = 0)) or
                  ((`db_ex_business`.`t_orders`.`order_state` in (2, 3, 6, 7)) and
                   (`db_ex_business`.`t_orders`.`goods_type` = 1))) then 3
            when ((`db_ex_business`.`t_orders`.`payment_type` in (7, 13, 14)) and
                  (`db_ex_business`.`t_orders`.`order_state` = 0) and
                  (`db_ex_business`.`t_orders`.`que_check_state` = 0) and
                  (`db_ex_business`.`t_orders`.`goods_type` = 0)) then 9
            when ((`db_ex_business`.`t_orders`.`order_state` = 0) and (`db_ex_business`.`t_orders`.`goods_type` = 1))
                then 10
            when ((`db_ex_business`.`t_orders`.`order_state` = 1) and (`db_ex_business`.`t_orders`.`ship_state` = 1) and
                  (`db_ex_business`.`t_orders`.`goods_type` = 1)) then 11
            when ((`db_ex_business`.`t_orders`.`order_state` = 1) and (`db_ex_business`.`t_orders`.`ship_state` = 2) and
                  (`db_ex_business`.`t_orders`.`goods_type` = 1)) then 12
            else 0 end)                       AS `state`,
       `db_ex_business`.`t_orders`.`app_id`   AS `app_id`,
       `db_ex_business`.`t_orders`.`order_id` AS `order_id`
from `db_ex_business`.`t_orders`;

-- comment on column order_state.app_id not supported: 应用Id

-- comment on column order_state.order_id not supported: 订单Id

