create
    definer = out_root@`%` procedure sp_gen_autoincr()
BEGIN
DECLARE num INT DEFAULT 1;
DECLARE ID_L varchar(64);
DECLARE done INT DEFAULT 0; 

DECLARE Res_Cur CURSOR FOR 
select id from t_audio_0706 order by created_at;

DECLARE CONTINUE HANDLER FOR NOT FOUND SET done=1; 
DECLARE EXIT HANDLER FOR SQLEXCEPTION ROLLBACK;

OPEN Res_Cur;
read_loop: LOOP
	FETCH Res_Cur INTO ID_L;
	IF done=1 THEN
		LEAVE read_loop;
	END IF;

	update t_audio_0706 set rid=num where id=ID_L limit 1;
	SET num=num+1;
END LOOP;
CLOSE Res_Cur;
END;

