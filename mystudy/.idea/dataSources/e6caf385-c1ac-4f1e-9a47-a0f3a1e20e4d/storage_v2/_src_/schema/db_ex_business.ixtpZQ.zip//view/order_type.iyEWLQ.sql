create view order_type as
select concat(`order_type_tmp`.`is_normal`, `order_type_tmp`.`is_gift`, `order_type_tmp`.`is_group`,
              `order_type_tmp`.`is_coupon`, `order_type_tmp`.`is_invite`, `order_type_tmp`.`is_convert`,
              `order_type_tmp`.`is_vip_renew`, `order_type_tmp`.`is_limit_discounts`, `order_type_tmp`.`is_fans_up`,
              `order_type_tmp`.`is_distribute`, `order_type_tmp`.`is_poster`, `order_type_tmp`.`is_spike`,
              `order_type_tmp`.`is_new_list`, `order_type_tmp`.`is_api`, `order_type_tmp`.`is_others`) AS `type`,
       `order_type_tmp`.`app_id`                                                                       AS `app_id`,
       `order_type_tmp`.`order_id`                                                                     AS `order_id`
from `db_ex_business`.`order_type_tmp`;

-- comment on column order_type.app_id not supported: 应用Id

-- comment on column order_type.order_id not supported: 订单Id

