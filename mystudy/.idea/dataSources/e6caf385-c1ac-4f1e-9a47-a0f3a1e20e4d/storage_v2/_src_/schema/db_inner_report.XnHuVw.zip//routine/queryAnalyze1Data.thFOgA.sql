create
    definer = root@`%` procedure queryAnalyze1Data()
BEGIN
	SELECT * FROM tb_balance TB WHERE TB.cell LIKE '%2%';
END;

