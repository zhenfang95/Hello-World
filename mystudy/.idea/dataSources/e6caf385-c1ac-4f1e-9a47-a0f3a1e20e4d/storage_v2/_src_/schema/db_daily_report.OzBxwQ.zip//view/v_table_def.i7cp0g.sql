create view v_table_def as
select `db_daily_report`.`t_table_def`.`f_id`                   AS `f_id`,
       `db_daily_report`.`t_table_def`.`f_table_key`            AS `f_table_key`,
       `db_daily_report`.`t_table_def`.`f_table_name`           AS `f_table_name`,
       `db_daily_report`.`t_table_def`.`f_table_desc`           AS `f_table_desc`,
       `db_daily_report`.`t_table_def`.`f_table_type`           AS `f_table_type`,
       `db_daily_report`.`t_table_def`.`f_security_class`       AS `f_security_class`,
       `db_daily_report`.`t_table_def`.`f_min_unit`             AS `f_min_unit`,
       `db_daily_report`.`t_table_def`.`f_scale`                AS `f_scale`,
       `db_daily_report`.`t_table_def`.`f_stat_unit`            AS `f_stat_unit`,
       `db_daily_report`.`t_table_def`.`f_update_rate`          AS `f_update_rate`,
       `db_daily_report`.`t_table_def`.`f_update_mode`          AS `f_update_mode`,
       `db_daily_report`.`t_table_def`.`f_data_scope`           AS `f_data_scope`,
       `db_daily_report`.`t_table_def`.`f_his_save`             AS `f_his_save`,
       `db_daily_report`.`t_table_def`.`f_data_source`          AS `f_data_source`,
       `db_daily_report`.`t_table_def`.`f_department`           AS `f_department`,
       `db_daily_report`.`t_table_def`.`f_theme_id`             AS `f_theme_id`,
       `db_daily_report`.`t_table_def`.`f_create_user`          AS `f_create_user`,
       `db_daily_report`.`t_table_def`.`f_modify_user`          AS `f_modify_user`,
       `db_daily_report`.`t_table_def`.`f_create_time`          AS `f_create_time`,
       `db_daily_report`.`t_table_def`.`f_modify_time`          AS `f_modify_time`,
       `db_daily_report`.`t_table_def`.`f_data_time`            AS `f_data_time`,
       `db_daily_report`.`t_table_def`.`f_valid`                AS `f_valid`,
       `db_daily_report`.`t_table_def`.`f_show_seq`             AS `f_show_seq`,
       `db_daily_report`.`t_table_def`.`f_monitor_mode`         AS `f_monitor_mode`,
       `db_daily_report`.`t_table_def`.`f_monitor_id`           AS `f_monitor_id`,
       `db_daily_report`.`t_table_def`.`f_principal`            AS `f_principal`,
       `db_daily_report`.`t_table_def`.`f_principal_pm`         AS `f_principal_pm`,
       `db_daily_report`.`t_table_def`.`f_database`             AS `f_database`,
       `db_daily_report`.`t_table_def`.`f_sync_palo`            AS `f_sync_palo`,
       `db_daily_report`.`t_table_def`.`f_right_type`           AS `f_right_type`,
       `db_daily_report`.`t_table_def`.`f_receiver`             AS `f_receiver`,
       `db_daily_report`.`t_table_def`.`f_check_time`           AS `f_check_time`,
       `db_daily_report`.`t_table_def`.`f_data_out_time`        AS `f_data_out_time`,
       `db_daily_report`.`t_table_def`.`f_store_engine_type`    AS `f_store_engine_type`,
       `db_daily_report`.`t_table_def`.`f_notice`               AS `f_notice`,
       `db_daily_report`.`t_table_def`.`f_hdfs_location`        AS `f_hdfs_location`,
       `db_daily_report`.`t_table_def`.`f_from_dw`              AS `f_from_dw`,
       `db_daily_report`.`t_table_def`.`f_detail_desc`          AS `f_detail_desc`,
       `db_daily_report`.`t_table_def`.`f_slice_field`          AS `f_slice_field`,
       `db_daily_report`.`t_table_def`.`f_time_field`           AS `f_time_field`,
       `db_daily_report`.`t_table_def`.`f_partition_field`      AS `f_partition_field`,
       `db_daily_report`.`t_table_def`.`f_show_case`            AS `f_show_case`,
       `db_daily_report`.`t_table_def`.`f_perfect_status`       AS `f_perfect_status`,
       `db_daily_report`.`t_table_def`.`f_perfect_level`        AS `f_perfect_level`,
       `db_daily_report`.`t_table_def`.`f_domain_id`            AS `f_domain_id`,
       `db_daily_report`.`t_table_def`.`f_gp_schema`            AS `f_gp_schema`,
       `db_daily_report`.`t_table_def`.`f_is_ods_tbl`           AS `f_is_ods_tbl`,
       `db_daily_report`.`t_table_def`.`f_imp_level`            AS `f_imp_level`,
       `db_daily_report`.`t_table_def`.`f_life_cycle`           AS `f_life_cycle`,
       `db_daily_report`.`t_table_def`.`f_clear_exempt_end`     AS `f_clear_exempt_end`,
       `db_daily_report`.`t_table_def`.`f_time_slice_field_key` AS `f_time_slice_field_key`
from `db_daily_report`.`t_table_def`;

-- comment on column v_table_def.f_id not supported: id

-- comment on column v_table_def.f_table_key not supported: 表名

-- comment on column v_table_def.f_table_name not supported: 表中文名

-- comment on column v_table_def.f_table_desc not supported: 表描述

-- comment on column v_table_def.f_table_type not supported: 1 "汇总" 2 "明细" 3 "维度"

-- comment on column v_table_def.f_security_class not supported: 密级，1 公开 2 保密 3 机密 4 绝密

-- comment on column v_table_def.f_min_unit not supported: 表最细粒度

-- comment on column v_table_def.f_scale not supported: 数据规模

-- comment on column v_table_def.f_stat_unit not supported: 统计时间周期

-- comment on column v_table_def.f_update_rate not supported: 更新频率:0不更新,1天,2周,3月,4季,5年

-- comment on column v_table_def.f_update_mode not supported: 更新方式:1全量2增量

-- comment on column v_table_def.f_data_scope not supported: 数据范围

-- comment on column v_table_def.f_his_save not supported: 历史数据保存时间

-- comment on column v_table_def.f_data_source not supported: 数据来源

-- comment on column v_table_def.f_department not supported: 负责部门

-- comment on column v_table_def.f_theme_id not supported: 归属主题

-- comment on column v_table_def.f_create_user not supported: 创建人

-- comment on column v_table_def.f_modify_user not supported: 最后修改人

-- comment on column v_table_def.f_create_time not supported: 创建时间

-- comment on column v_table_def.f_modify_time not supported: 最后修改时间

-- comment on column v_table_def.f_show_seq not supported: 顺序

-- comment on column v_table_def.f_monitor_mode not supported: 监控模式 

-- comment on column v_table_def.f_monitor_id not supported: 监控ID 

-- comment on column v_table_def.f_principal not supported: 负责人

-- comment on column v_table_def.f_principal_pm not supported: 负责PM

-- comment on column v_table_def.f_database not supported: 所属数据库

-- comment on column v_table_def.f_sync_palo not supported: 表结构是否同步palo

-- comment on column v_table_def.f_right_type not supported: 1:普通表,所有SQL操作台用户可看;2:特殊表，指定人员可看

-- comment on column v_table_def.f_receiver not supported: 告警接收人

-- comment on column v_table_def.f_check_time not supported: 告警检测时间

-- comment on column v_table_def.f_data_out_time not supported: 数据产出时间

-- comment on column v_table_def.f_store_engine_type not supported: 配置表所属存储引擎 1：MYSQL，2：PALO，3：以上两者,4: HIVE ,5:HIVE和PALO，6:PALO2

-- comment on column v_table_def.f_notice not supported: 注意事项

-- comment on column v_table_def.f_hdfs_location not supported: HDFS路径

-- comment on column v_table_def.f_from_dw not supported: 是否从数据仓库接入

-- comment on column v_table_def.f_detail_desc not supported: 详细介绍 http网址

-- comment on column v_table_def.f_slice_field not supported: 时间切片字段

-- comment on column v_table_def.f_time_field not supported: 主时间字段

-- comment on column v_table_def.f_partition_field not supported: 分区字段

-- comment on column v_table_def.f_show_case not supported: 默认显示的案例id

-- comment on column v_table_def.f_perfect_status not supported: 表完善状态；1-待完善，2-完善；3-数易可用

-- comment on column v_table_def.f_perfect_level not supported: 表完善状态；1-待完善，2-完善；3-数易可用

-- comment on column v_table_def.f_domain_id not supported: 数据域分类主题id，关联t_data_domain表

-- comment on column v_table_def.f_gp_schema not supported: 所属schema名，关联t_gp_schema表

-- comment on column v_table_def.f_is_ods_tbl not supported: 是否为历史ODS表

-- comment on column v_table_def.f_imp_level not supported: 数据源分级；1-未定义；2-P0级；3-P1级；4-P2级别。

-- comment on column v_table_def.f_life_cycle not supported: 数据生命周期，天数，-1表示永久

-- comment on column v_table_def.f_clear_exempt_end not supported: 数据清理豁免结束日期

-- comment on column v_table_def.f_time_slice_field_key not supported: 时间分片字段名称

