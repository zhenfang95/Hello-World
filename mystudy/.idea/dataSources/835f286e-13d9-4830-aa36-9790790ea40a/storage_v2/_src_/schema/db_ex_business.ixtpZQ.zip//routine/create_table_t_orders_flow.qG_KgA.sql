create
    definer = root@`%` procedure create_table_t_orders_flow()
BEGIN
set @suffix=date_format(now(), '%Y_%m');
set @sqlStr=CONCAT('CREATE TABLE t_orders_flow_',@suffix, "(

`id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增id',
`app_id` varchar(64) NOT NULL COMMENT '应用Id',
`content_app_id` varchar(64) DEFAULT NULL COMMENT '内容方应用Id',
`order_id` varchar(64) NOT NULL COMMENT '订单Id',
`flow_type` int(11) DEFAULT NULL COMMENT '流水类型，后面要根据实际的情况调整 ：100-待支付内部订单 101-支付成功内部订单 102-退款内部订单 103-关闭内部订单 104-取消内部订单 105-支付失败内部订单 106-支付成功交易中内部订单 107-结算内部订单 108-人工取消订单 110-实物订单确认收货 112-实物订单已收货 114-拼团/问答订单交易成功 120-待支付外部订单 121-支付成功外部订单 122-退款外部订单 125-支付失败外部订单 126-支付成功交易中外部订单 ',
`user_id` varchar(64) NOT NULL COMMENT '用户id',
`pay_way` int(1) DEFAULT '0' COMMENT '支付渠道 默认0 -1-未指定支付方式 0-线上微信 1-线上支付宝 2-IOS支付',
`payment_type` int(11) NOT NULL COMMENT '付费类型：2-单笔、3-付费产品包、4-团购、5-单笔的购买赠送、6-产品包的购买赠送、7-问答提问、8-问答偷听、9-购买会员、10-会员的购买赠送、11-付费活动报名、12-打赏类型 13-单笔拼团 14-付费产品包拼团',
`resource_type` int(11) NOT NULL COMMENT '资源类型：0-无（不通过资源的购买入口，如团购）、1-图文、2-音频、3-视频、4-直播、5-活动报名(若payment_type=14时，5-会员)、6-专栏、7-社群、8-大专栏、20-电子书',
`resource_id` varchar(64) DEFAULT NULL COMMENT '资源物品标识，单笔时为买的资源的id, 付费产品包时为通过哪个资源id而产生的点击购买行为，团购时为团购配置表的id，问答提问和偷听均为问题的id',
`product_id` varchar(64) DEFAULT NULL COMMENT 'payment_type为2时-NULL, payment_type为3时-绑定的付费产品包id，payment_type为4时留空',
`count` int(11) DEFAULT '1' COMMENT '购买数量，默认为1，团购时按实际情况填写',
`channel_id` varchar(64) DEFAULT NULL COMMENT '渠道id',
`channel_info` varchar(64) DEFAULT '' COMMENT '渠道来源',
`share_user_id` varchar(64) DEFAULT NULL COMMENT '若是来自分享，填写分享人的id;',
`share_type` int(11) DEFAULT NULL COMMENT '分享类型 0-音频分享 1-日签分享 2-专栏分享 4-邀请卡分享 5-推广分销分享 6- 推广分销平台 8-裂变海报分销分享',
`purchase_name` varchar(64) DEFAULT NULL COMMENT '购买的资源名',
`img_url` varchar(256) DEFAULT NULL COMMENT '资源配图url',
`cu_id` varchar(64) NOT NULL DEFAULT '' COMMENT '用户优惠券id',
`cou_price` int(11) NOT NULL DEFAULT '0' COMMENT '优惠价格:分',
`discount_id` varchar(64) NOT NULL DEFAULT '' COMMENT '折扣id 若payment_type为13、14时存拼团(大团)id',
`discount_price` int(11) NOT NULL DEFAULT '0' COMMENT '折扣减免的价格:分',
`price` int(11) DEFAULT NULL COMMENT '价格（分）',
`order_state` int(1) NOT NULL DEFAULT '0' COMMENT '订单状态：0-未支付 1-支付成功 2-支付失败 3-退款 4-预定(如问答的提问，未使用) 5(未使用) 6-订单过期自动取消 7-手动取消订单',
`goods_type` int(1) NOT NULL DEFAULT '0' COMMENT '商品类型(0-虚拟商品 1-实物商品)',
`ship_state` int(1) NOT NULL DEFAULT '0' COMMENT '发货状态(0-禁止发货 1-待发货 2-已发货 3-已收货) (目前仅用于实物商品)',
`out_order_id` varchar(64) DEFAULT NULL COMMENT '成功支付的外部订单号(out_orders)',
`transaction_id` varchar(64) DEFAULT NULL COMMENT '微信支付交易单号',
`wx_app_type` int(11) DEFAULT '1' COMMENT '数据来源 0-小程序 1-公众号 10-开放平台 11-PC通用版 12-App',
`period` int(11) DEFAULT NULL COMMENT '有效期（秒）null则不限时间',
`use_collection` int(11) DEFAULT '0' COMMENT '是否是来自代收 0-否 1-是',
`settle_status` int(1) NOT NULL DEFAULT '0' COMMENT '结算状态（0-未结算；1-结算中；2-结算完成）',
`distribute_type` int(1) NOT NULL DEFAULT '0' COMMENT '0.普通订单 1.分销订单',
`distribute_price` int(11) DEFAULT NULL COMMENT '分销提成（分）；若是问答，填写答主分成（分）',
`distribute_percent` int(11) DEFAULT NULL COMMENT '分销比例(百分点1-100) 若是问答，填写答主的分成比例（百分点1-100）',
`superior_distribute_user_id` varchar(64) DEFAULT NULL COMMENT '上级分销用户id 若是问答中的偷听类型，填写提问者的id,当share_type等于6的时候为平台id',
`superior_distribute_price` int(11) DEFAULT NULL COMMENT '上级分销提成（分）提问者的分成提成（分）',
`superior_distribute_percent` int(11) DEFAULT NULL COMMENT '上级分销比例(百分点1-100)； 提问人的分成比例（百分点1-100）',
`related_id` varchar(64) null comment '订单关联的id 分销时为t_distribute_detail表的id；若payment_type为问答提问，则存储答主id,若payment_type为13,14时存小团id；活动购票则存票种id',
`is_renew` int(11) DEFAULT '0' COMMENT '是否是续费订单：默认0-普通订单、1-会员续费、2-过期后购买、3-删除后购买',
`source` int(11) NOT NULL DEFAULT '0' COMMENT '0-B端客户订单 1-小鹅通精选订单 2-内容市场',
`agent` varchar(512) DEFAULT NULL COMMENT '设备信息',
`pay_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '支付时间',
`settle_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '结算时间',
`refund_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '退款时间',
`refund_money` int(11) DEFAULT NULL COMMENT '价格（分）',
`remark` varchar(1024) DEFAULT '' COMMENT '流水备注',
`invalid_time` timestamp NULL DEFAULT '0000-00-00 00:00:00' COMMENT '订单过期时间',
`que_check_state` int(2) NOT NULL DEFAULT '0' COMMENT '问答/拼课订单核算状态；0-未核算；1-已核算；2-核算失败（payment_type = 8时该字段值为1，算作问答大类，其他情况为0.）',
`order_created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '订单创建时间',
`created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '创建时间',
`is_deleted` tinyint(1) DEFAULT '0' COMMENT '0-正常 1-已删除',
PRIMARY KEY (`id`),
KEY `index_app_order_flow_type` (`app_id`,`order_id`,`flow_type`),
KEY `index_created_at` (`created_at`)

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单(内部/外部)流水'; 
");
PREPARE stmt from @sqlStr;
EXECUTE stmt;

END;

